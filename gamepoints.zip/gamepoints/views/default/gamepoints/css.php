<?php
	/**
	 * gamepoint CSS
	 */
?>

.gamepoints_profile{
    font-weight: bold; 
    padding: 3px 0 3px 5px;
    margin-top: 10px;
    background:white;
}

/* ------ gamepoints widgets ------  */

#gamepoints_mypoints_widget_container {
    text-align:left;
}

#gamepoints_toppoints_widget_container {
    text-align:left;
    /* background-color:#00ffff; */
}
    
.gamepoints_actions h3 {
    color:#4690D6;
}
.gamepoints_actions label {
    font-size:12px;
}
